<?php
$gname= array ("a","b","c","d","e","f","g","h"); 
$ofname1= array ("a","c","b","d","e","g","f","h");	
$ofname2= array ("b","d","a","c","f","h","e","g");
$cfname1= array ("1","5","3","7");
$cfname2= array ("2","6","4","8");
$cuartos=array ("a","b","c","d");
$sfname1= array ("a","c");
$sfname2= array ("b","d");
$semifinal=array ("I","II");




$groupa = array (                      
			array(1,"GrupoA","Rusia","0","0","Egipto"),
			array(2,"GrupoA","A.Saudita","","","Uruguay"),
			array(17,"GrupoA","Rusia","","","Uruguay"),
			array(18,"GrupoA","Egipto","","","A.Saudita"),
			array(33,"GrupoA","Uruguay","","","A.Saudita"),
			array(34,"GrupoA","Rusia","","","Egipto"),);
										
$groupb = array (                      
			array(3,"GrupoB","Marruecos","","","Portugal"),
			array(4,"GrupoB","Iran","","","Espana"),
			array(19,"GrupoB","Portugal","","","Iran"),
			array(20,"GrupoB","Marruecos","","","Espana"),
			array(35,"GrupoB","Iran","","","Espana"),
			array(36,"GrupoB","Portugal","","","Marruecos"),);
										
										
$groupc = array (                      
			array(5,"GrupoC","Francia","","","Peru"),
			array(6,"GrupoC","Australia","","","Dinamarca"),
			array(21,"GrupoC","Francia","","","Dinamarca"),
			array(22,"GrupoC","Peru","","","Australia"),
			array(37,"GrupoC","Dinamarca","","","Australia"),
			array(38,"GrupoC","Francia","","","Peru"));
											
$groupd = array (                      
			array(7,"GrupoD","Argentina","","","Croacia"),
			array(8,"GrupoD","Islandia","","","Nigeria"),
			array(23,"GrupoD","Argentina","","","Nigeria"),
			array(24,"GrupoD","Croacia","","","Islandia"),
			array(39,"GrupoD","Nigeria","","","Islandia"),
			array(40,"GrupoD","Argentina","","","Croacia"));								

$groupe = array (                      
			array(9,"GrupoE","Costa Rica","","","Brasil"),
			array(10,"GrupoE","Serbia","","","Suiza"),
			array(25,"GrupoE","Brasil","","","Serbia"),
			array(26,"GrupoE","Costa Rica","","","Suiza"),
			array(41,"GrupoE","Serbia","","","Suiza"),
			array(42,"GrupoE","Brasil","","","Costa Rica"));
$groupf = array (                      
			array(11,"GrupoF","Alemania","","","Suecia"),
			array(12,"GrupoF","Mexico","","","Corea"),
			array(27,"GrupoF","Alemania","","","Corea"),
			array(28,"GrupoF","Suecia","","","Mexico"),
			array(43,"GrupoF","Corea","","","Mexico"),
			array(44,"GrupoF","Alemania","","","Suecia"));
$groupg =  array (                      
			array(13,"GrupoG","Belgica","","","Tunez"),
			array(14,"GrupoG","Panama","","","Inglaterra"),
			array(29,"GrupoG","Belgica","","","Inglaterra"),
			array(30,"GrupoG","Tunez","","","Panama"),
			array(45,"GrupoG","Inglaterra","","","Panama"),
			array(46,"GrupoG","Belgica","","","Tunez"));
			
$grouph =  array (                      
			array(15,"GrupoH","Polonia","","","Colombia"),
			array(16,"GrupoH","Senegal","","","Japon"),
			array(31,"GrupoH","Polonia","","","Japon"),
			array(32,"GrupoH","Colombia","","","Senegal"),
			array(47,"GrupoH","Japon","","","Senegal"),
			array(48,"GrupoH","Polonia","","","Colombia"));
			
$octavos = array (                      
			array(49,"Octavos","","",0,0,0,0),
			array(50,"Octavos","","",0,0,0,0),
			array(51,"Octavos","","",0,0,0,0),
			array(52,"Octavos","","",0,0,0,0),
			array(53,"Octavos","","",0,0,0,0),
			array(54,"Octavos","","",0,0,0,0),
			array(55,"Octavos","","",0,0,0,0),
			array(56,"Octavos","","",0,0,0,0),);
			
$cuartos = array (                      
			array(57,"Cuartos","","",1,1,2,1),
			array(58,"Cuartos","","",0,0,0,0),
			array(59,"Cuartos","","",0,0,0,0),
			array(60,"Cuartos","","",0,0,0,0),);

$semi = array (                      
			array(61,"Semifinal","","",0,0,0,0),
			array(62,"Semifinal","","",0,0,0,0),);
			
$tercer= array (                      
			array(63,"TerceryCuarto","","",0,0,0,0),);			
		
$final = array (                      
			array(64,"Final","","",0,0,0,0),);		

$campeon ="";
		?>								